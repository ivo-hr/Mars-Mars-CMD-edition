# sharpPhysics
2D physics engine in C#

https://youtu.be/O_O9jhB9bcI

![Screenshot](https://user-images.githubusercontent.com/21973290/88493117-6d4f5a00-cf7d-11ea-96c7-579df0e7436a.png)

Controls as of right now:

* LMB: Move existing objects or create/launch new ones
* RMB: Delete objects on click / mouse move
* P: Switch to poolball shader
* V: Switch to velocity shader
* W: Switch to "water" shader
* I: Switch to info shader
* G: Create Gravity orb
* SPACE: Stop all object momentum (momentarily)

Tutorials I worked with to create this:

* This Chapeter of this impossible to find tutorial (timer / main loop logic)
  
    http://what-when-how.com/Tutorial/topic-103/C-Game-Programming-For-Serious-Game-Creation-97.html
    
* This c++ engine tutorial (Up to the rotational calculations)

    https://gamedevelopment.tutsplus.com/tutorials/how-to-create-a-custom-2d-physics-engine-the-basics-and-impulse-resolution--gamedev-6331
