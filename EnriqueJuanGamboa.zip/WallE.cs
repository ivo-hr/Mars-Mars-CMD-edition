﻿//Enrique Juan Gamboa

using System;

namespace prac2
{
    class WallE
    {
        int pos;            //Walle position
        Listas bag;  //Walle's bag

        //walle constructor
        public WallE()
        {
            pos = 0;
            bag = new Listas();
        }

        //Walle position
        public int GetPosition()
        {
            int wPos = pos; //Int to return + walle position
            return wPos;    //position return
        }

        //Item number in bag
        public int GetNumItemsBag()
        {
            int nItBag = bag.NumElems(); //Int to return + num items in bag
            return nItBag;               //number return
        }

        //Walle movement
        public void Move(Map m, Direction dir)
        {
            int mov = m.Move(pos, dir);                         //New position

            //if new position exists, change Walle position
            if (mov != -1) 
                pos = mov;
            //if not
            else 
                throw new Exception("Can't move there...");
        }

        //Item pickup
        public void PickItem(Map m, int placeItemIndex)
        {
            m.PickItemPlace(pos, placeItemIndex);   //Remove item from place

            bag.InsertaFinal(placeItemIndex);       //Add item in bag
        }

        //Item dropping
        public void DropItem(Map m, int placeItemIndex)
        {
            m.DropItemPlace(pos, bag.nEsimo(placeItemIndex));   //Add item to place

            bag.EliminaElto(bag.nEsimo(placeItemIndex));        //Remove item from bag
        }

        //items in bag information
        public string Bag(Map m)
        {
            string info = "";                           //String to return

            //Loop to get items ing bag info
            for(int i = 0; i < bag.NumElems(); i++)
            {
                info += i + m.ItemInfo(bag.nEsimo(i));
            }

            return info;                                //Info return
        }

        //Walle at spaceship detector
        public bool AtSpaceShip(Map m)
        {
            bool toRet = false;                     //bool to return

            //If spaceship at Walle's position
            if(m.isSpaceShip(pos)) 
                toRet = true;

            return toRet;                           //at spaceship return
        }
    }
}
