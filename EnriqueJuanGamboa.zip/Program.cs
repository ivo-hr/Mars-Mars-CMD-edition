﻿//Enrique Juan Gamboa

using System;

namespace prac2
{
    class Program
    {
        static void Main(string[] args)
        {
            
            string file = "madrid";         //map name

            //Load custom map. If no input, loads default map madrid
            Console.ForegroundColor = ConsoleColor.DarkGray;
            Console.WriteLine("What map would you like to load? ");
            string mapN = Console.ReadLine();
            if (mapN == "")
            {
                Console.WriteLine("No text detected. Loading default map " + file);
            }
            else file = mapN;


            //Map creation
            Map map = new Map(10, 10);
            map.ReadMap(file + ".map");

            
            WallE wally = new WallE();      //Walle creation

            //Starting message
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("\n\nWELCOME, WALL-E, TO THE DESOLATE LAND OF " + file + "\n\n");
            Console.WriteLine(map.GetPlaceInfo(0) + "\n");
            Console.ForegroundColor = ConsoleColor.DarkCyan;
            Console.WriteLine("Write 'h' for a command list");

            Console.ForegroundColor = ConsoleColor.DarkGray;
            string input = "";              //String for player input

            bool end = false;               //End of game command

            //M A I N  L O O P
            while (!wally.AtSpaceShip(map) && !end)
            {
                input = Console.ReadLine();             //Player input
                
                //End game though command
                if (input == "end")
                    end = true;

                //Play game
                else
                {
                    Console.WriteLine("\n\n");          //Line sapcing

                    ProcesaInput(input, wally, map);    //Input processing and text writing
                    Console.WriteLine("\n");
                    Console.ForegroundColor = ConsoleColor.DarkGray;
                }
            }

            //If finished the game
            if (wally.AtSpaceShip(map))
            {
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.WriteLine("\n Good Job Wall-E! There's a spaceship here, let's go back to the Axiom.");
                Console.WriteLine("You picked up " + wally.GetNumItemsBag() + " out of " + map.nItems + " pieces of trash.");
            }

            Console.ForegroundColor = ConsoleColor.Black;
        }

        //Input processing and text writing
        static void ProcesaInput(string com, WallE w, Map m)
        {
            string[] splitInput = com.Split(' ');       //Input divided to string array

            //First word
            switch (splitInput[0])
            {
                //Move command
                case "go":
                    try
                    {
                        bool moved = true;                  //to write specific messages

                        //Direction moved switch
                        switch (splitInput[1])
                        {
                            case "north":
                                w.Move(m, Direction.North);
                                break;
                            case "east":
                                w.Move(m, Direction.East);
                                break;
                            case "south":
                                w.Move(m, Direction.South);
                                break;
                            case "west":
                                w.Move(m, Direction.West);
                                break;

                                //If not valid direction
                            default:
                                moved = false;
                                Console.ForegroundColor = ConsoleColor.DarkRed;
                                Console.WriteLine("Not a valid direction: " + splitInput[1]);
                                break;
                        }
                        //If movement successful
                        if (moved)
                        {
                            Console.ForegroundColor = ConsoleColor.Cyan;
                            Console.WriteLine("You moved to " + m.PlaceName(w.GetPosition()));

                            Console.ForegroundColor = ConsoleColor.White;
                            Console.WriteLine(m.GetPlaceInfo(w.GetPosition()));
                        }
                    }
                    
                    //If valid direction but can't move there
                    catch 
                    {
                        Console.ForegroundColor = ConsoleColor.Magenta;
                        Console.WriteLine("You can't move there!");
                    }

                    break;

                //Pickup command
                case "pick":
                    try
                    {
                        int itemN = int.Parse(splitInput[1]);       //Item to pick up

                        //Item pickup
                        try
                        {
                            w.PickItem(m, itemN);

                            Console.ForegroundColor = ConsoleColor.Green;
                            Console.WriteLine("Trash picked!");
                        }
                        //If item doesn't exist
                        
                        catch 
                        {
                            Console.ForegroundColor = ConsoleColor.Magenta;
                            Console.WriteLine("That trash doesn't exist: " + itemN); 
                        }
                    }
                    //If item number not a number
                    
                    catch 
                    {
                        Console.ForegroundColor = ConsoleColor.DarkRed;
                        Console.WriteLine("Not a valid number!"); 
                    }

                    break;

                //Drop command
                case "drop":
                    try 
                    { 
                        int itemN = int.Parse(splitInput[1]);       //Item to drop

                        //Item drop
                        try
                        {
                            w.DropItem(m, itemN);

                            Console.ForegroundColor = ConsoleColor.Red;
                            Console.WriteLine("Trash dropped!");
                        }
                        //If item doesn't exist
                        catch 
                        {
                            Console.ForegroundColor = ConsoleColor.Magenta;
                            Console.WriteLine("That trash doesn't exist: " + itemN); 
                        }
                    }

                    //If item number not a number
                    catch 
                    {
                        Console.ForegroundColor = ConsoleColor.DarkRed;
                        Console.WriteLine("Not a valid number!"); 
                    }

                    break;

                //Item info command
                case "items":
                    //Item info in place writer
                    try 
                    {
                        Console.ForegroundColor = ConsoleColor.Yellow;
                        Console.WriteLine(m.GetItemsInPlace(w.GetPosition())); 
                    }
                    //If there are no items in place
                    catch 
                    {
                        Console.ForegroundColor = ConsoleColor.Magenta;
                        Console.WriteLine("No trash here..."); 
                    }

                    break;

                //Place info command
                case "info":
                    //Place info writer
                    Console.ForegroundColor = ConsoleColor.White;
                    Console.WriteLine(m.GetPlaceInfo(w.GetPosition()));

                    break;

                //Bag info command
                case "bag":

                    Console.ForegroundColor = ConsoleColor.Gray;
                    //Bag info
                    string content = "ITEMS IN THE BAG: \n" + w.Bag(m);

                    //If nothing in bag
                    if (content == "") 
                        content = "You haven't picked up anything yet...";

                    else 
                        content += "\n You have " + w.GetNumItemsBag() + " items.";

                    //Bag info writer
                    Console.WriteLine(content);

                    break;

                //Command list command
                case "h":
                    //Command list writer
                    HelpWrite();

                    break;

                //If command doesn't exist
                default:
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("That command doesn't exist! Write 'h' for a command list");

                    break;
            }
        }

        //Command list writer
        static void HelpWrite()
        {
            Console.ForegroundColor = ConsoleColor.DarkCyan;
            Console.WriteLine("COMMANDS:");
            Console.WriteLine("\n");
            Console.WriteLine("-> go (direction): move either north, south, east or west");
            Console.WriteLine("-> info: description of your current location");
            Console.WriteLine("\n");
            Console.WriteLine("-> items: trash available to pick up in the current location, in a list");
            Console.WriteLine("-> pick (number): pick a piece if trash from the list. Count starts from the first piece");
            Console.WriteLine("\n");
            Console.WriteLine("-> bag: trash you already picked up in a list");
            Console.WriteLine("-> drop (number): throw a piece if trash from the list. Count starts from the first piece");
            Console.WriteLine("\n");
            Console.WriteLine("-> h: see command list");
            Console.WriteLine("-> end: close game");
        }
    }
}

