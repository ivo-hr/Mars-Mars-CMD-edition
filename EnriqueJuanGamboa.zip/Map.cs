﻿//Enrique Juan Gamboa

using System;
using System.IO;

namespace prac2
{
	public enum  Direction { North, South, East, West};		//Direction enum
	class Map
	{
		//Items struct
		struct Item
        {
			public string name, description;
        }
		//Places struct
		struct Place
        {
			public string name, description;
			public bool spaceShip;
			public int[] connections;

			public Listas itemsInPlace;
        }
		//All places and items and number of them
		Place[] places;
		Item[] items;
		public int nPlaces, nItems;

		//Map constructor
		public Map(int numPlaces, int numItems)
        {
			places = new Place[numPlaces];
			items = new Item[numItems];
        }

		//File to map
		public void ReadMap(string file)
        {
            try
            {
				StreamReader fIn = new StreamReader(file);


				nItems = 0;                                             //Item number init
				nPlaces = 0;                                            //Places number init
				//Reading loop
				while (!fIn.EndOfStream)
				{
					string line = fIn.ReadLine();                       //Read new line
					string[] wrd = line.Split(' ');                     //Split in array of words

					//Read element type switch
					switch (wrd[0])
					{
						case "place":
							CreatePlace(wrd, fIn, places);  //Place creation
							nPlaces++;                                  //Add to place count
							break;
						case "garbage":
							CreateItem(wrd, items, places, nItems);     //Item creation
							nItems++;                                   //Add to item count + item number counter
							break;
						case "street":
							CreateStreet(wrd, places);                  //Street creation
							break;
					}
				}

				fIn.Close();                                            //File colse

			}

			//In case the file isn't found or places/items go outside bounds
			catch
			{
				Console.ForegroundColor = ConsoleColor.DarkRed;
				Console.WriteLine("CRITICAL: file not found/excess of places or items: " + file);
				Console.ForegroundColor = ConsoleColor.White;
				Console.WriteLine("\nPlease place " + file + " either in:");
				Console.WriteLine("bin/Debug/net6.0, if you're using .NET 6.0");
				Console.WriteLine("bin/Debug/net5.0, if you're using .NET 5.0");
				Console.WriteLine("\nAlso be sure the number of places or items in " + file + " DON'T exceed 10");
				Console.ForegroundColor = ConsoleColor.DarkGray;
				Environment.Exit(1);
			}
		}




		//Place creator
		private void CreatePlace(string[] pal, StreamReader fIn, Place[] places)
        {
			//place to add initialization
			Place plc = default;
			plc.connections = new int[4];
			nPlaces = int.Parse(pal[1]);

			plc.name = pal[2];                          //Place name

			plc.description = ReadDescription(fIn);     //Place description

			//Place connections initialization
			for (int i = 0; i < 4; i++)
				plc.connections[i] = -1;

			plc.itemsInPlace = new Listas();		//Place items initialization

			plc.spaceShip = (pal[3] == "spaceShip");	//Spaceship in place

			places[nPlaces] = plc;						//Addition of place
        }

		//Street creator
		private void CreateStreet(string[] pal, Place[] places)
		{
			//Starting (A) and ending (B) place
			int plcA = int.Parse(pal[1]);
			int plcB = int.Parse(pal[3]);
			
			Direction dirAB = default, dirBA = default;      //Direction of street depending on which end initialization

			//Direction of street assign
			switch (pal[2])
            {
				case "north":
					dirAB = Direction.North;
					dirBA = Direction.South;
					break;
				case "east":
					dirAB= Direction.East;
					dirBA = Direction.West;
					break;
				case "south":
					dirAB = Direction.South;
					dirBA = Direction.North;
					break;
				case "west":
					dirAB = Direction.West;
					dirBA = Direction.East;
					break;
			}

			//Street to places linking
			places[plcA].connections[(int)dirAB] = plcB;
			places[plcB].connections[(int)dirBA] = plcA;
		}

		//Item creator
		private void CreateItem(string[] pal, Item[] items, Place[] places, int point)
		{
			int plc = int.Parse(pal[2]);						//Where the item is
			
			items[point].name = pal[3];							//Item name

			//Item description
			for (int i = 4; i < pal.Length; i++)
				items[point].description += pal[i] + " ";



			places[plc].itemsInPlace.InsertaFinal(point);		//Item insertion

		}

		//Place information reader
		public string GetPlaceInfo(int pl)
        {
			string info = places[pl].name + "\n" + places[pl].description + "\n\n";                      //String to return + Description of place

			
			info += GetMoves(pl);												//Connections to the place

			return info;														//Info return
        }

		//Description reader
		private string ReadDescription(StreamReader f)
        {
			string line = f.ReadLine();					//New line
			string desc = "";							//String to return

			//Loop to read whole description
			bool end = false;
			while (!end)
            {
				desc += line;

				//If reached end of description
				if(line[line.Length - 1] == '"')
					end = true;

				line = f.ReadLine();					//New line
            }

			return desc;								//description return
        }

		//Connections to a place
		public string GetMoves(int pl)
        {
			string mov = "";													//String to return

			//Loop to write all avialable connections
			for (int i = 0; i < 4; i++)
			{
				int con = places[pl].connections[i];

				//if connection exists, write
				if (con != -1)
					switch (i)
					{
						case 0:
							mov += "North: " + PlaceName(con) + "\n";
							break;
						case 1:
							mov += "South: " + PlaceName(con) + "\n";
							break;
						case 2:
							mov += "East: " + PlaceName(con) + "\n";
							break;
						case 3:
							mov += "West: " + PlaceName(con) + "\n";
							break;
					}
			}

			return mov;														//availabel connections return
		}

		//Items in a place
		public string GetItemsInPlace(int pl)
        {
			string info = "";										//String to return

			int numItems = places[pl].itemsInPlace.NumElems();		//item number in the place

			//Loop to get all itemps currently in the place
			for (int i = 0; i < numItems; i++)
            {

				int itPl = places[pl].itemsInPlace.nEsimo(i);

				info += itPl + ItemInfo(itPl);

			}

			//If there are no items
			if (info == "")
				info = "Nothing here...";

			return info;											//info return

		}

		//Item remover when pickup
		public void PickItemPlace(int pl, int placeItemIndex)
        {
			//If item doesnt exist
			if (!places[pl].itemsInPlace.BuscaDato(placeItemIndex))
				throw new Exception("That item doesn't exist!");
			//If it does, delete item from place
            else
				places[pl].itemsInPlace.EliminaElto(placeItemIndex);
        }

		//Item adder when drop
		public void DropItemPlace(int pl, int it)
		{
			places[pl].itemsInPlace.InsertaFinal(it);		//Item addition
		}

		//Place reached after movement in a direction
		public int Move(int pl, Direction dir)
        {
			int whereTo = places[pl].connections[(int)dir];		//int to return + Place moved to

			return whereTo;										//place return
        }

		//Is there a spaceship an a place
		public bool isSpaceShip(int pl)
        {
			bool isThere = places[pl].spaceShip;	//bool to return + spaceship read

			return isThere;							//spaceship return
        }

		//Item information
		public string ItemInfo(int itemNo)
        {
			string info = " " + items[itemNo].name + ": " + items[itemNo].description + "\n";	//string to return + item information

			return info;																		//info return
        }

		//Name of a place
		public string PlaceName(int num)
        {
			string name = places[num].name;	//String to return + place name

			return name;					//name return

		}
	}
}

