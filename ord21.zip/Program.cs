﻿// Nombre Apellido1 Apellido2
// Laboratorio:    Puesto:   

//*******************


using System;
using System.IO;

namespace takuzu{
    class Program{
        static void Main(string[] args){
            const int N = 4;
            char [,] tab;
            tab = new char[N,N] {    // tablero del ejemplo   
                 {'.','1','.','0'},  // fila 0 
                 {'.','.','0','.'},  // fila 1
                 {'.','0','.','.'},  // etc
                 {'1','1','.','0'} };    
        
            bool [,] fijas = new bool[N,N]; // matriz de posiciones fijas
            int fil, col; // posición del cursor

            // ...
        }


        public static void InicializaFijas(char [,] tab, bool [,] fijas, int fil, int col){    
        }

        public static void Renderiza(char [,] tab, bool [,] fijas, int fil, int col){            
        }

        public static void ProcesaInput(char c, char [,] tab, bool [,] fijas, int fil, int col){
        }

        public static bool TabLleno(char [,] tab){
        }


        public static void SacaFilCol(int k, char [,] tab, char [] filk, char [] colk){                        
        }

        public static bool TresSeguidos(char [] v){
        }


        public static bool IgCerosUnos(char [] v){   
        }


        public static void MuestraResultado(char [,] tab){
        }


        public static void LeeArchivo(string file, char [,] tab){
        }


        static char LeeInput(){
			char d = ' ';
			while (d == ' ') {
				if (Console.KeyAvailable) {	
					string tecla = Console.ReadKey(true).Key.ToString ();
					switch (tecla) {
					case "LeftArrow":  d = 'l'; break;
					case "UpArrow":    d = 'u'; break;
					case "RightArrow": d = 'r'; break;
					case "DownArrow":  d = 'd';	break;
                    case "D0":         d = '0'; break;  // dígito 0
                    case "D1":         d = '1'; break;  // dígito 1                
                    case "Spacebar":   d = '.'; break;  // casilla vacia 
                    case "Escape":     d = 'q'; break;  // terminar					
                    default:           d = ' '; break;
					}
				}
			}
			return d;
		} // LeeInput
        
    }
}
